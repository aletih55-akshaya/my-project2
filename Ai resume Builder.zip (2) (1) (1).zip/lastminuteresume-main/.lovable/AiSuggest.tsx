import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Loader2, RotateCcw, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getSuggestions } from "@/lib/ai.functions";
import { toast } from "sonner";

type Field = "summary" | "experience" | "education" | "skills" | "projects" | "certifications" | "additional";

export function AiSuggest({ field, text, context, onApply }: { field: Field; text: string; context?: string; onApply: (v: string) => void }) {
  const run = useServerFn(getSuggestions);
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [items, setItems] = useState<string[]>([]);
  const [error, setError] = useState("");

  async function go() {
    if (!text.trim()) { setStatus("error"); setError("Write something first — suggestions are based on your own text."); return; }
    setStatus("loading"); setError("");
    try {
      const r = await run({ data: { field, text, context } });
      if (r.ok) { setItems(r.suggestions); setStatus("done"); }
      else { setError(r.error); setStatus("error"); }
    } catch {
      setError("Couldn't reach the AI service. Check your connection and retry."); setStatus("error");
    }
  }

  return (
    <div className="mt-2">
      <Button type="button" variant="outline" size="sm" onClick={go} disabled={status === "loading"}>
        {status === "loading" ? <Loader2 className="animate-spin" /> : <Sparkles />} Get AI Suggestions
      </Button>
      {status === "error" && (
        <div className="mt-2 flex items-center justify-between gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-2 text-xs text-destructive">
          <span>{error}</span>
          {text.trim() && <Button type="button" size="sm" variant="ghost" onClick={go}><RotateCcw /> Retry</Button>}
        </div>
      )}
      {status === "done" && (
        <div className="mt-2 space-y-2 rounded-md border bg-muted/50 p-2">
          {items.length === 0 && <p className="text-xs text-muted-foreground">No suggestions this time — your text may already be in good shape.</p>}
          {items.map((s, i) => (
            <div key={i} className="rounded border bg-card p-2 text-sm">
              <p className="whitespace-pre-line">{s}</p>
              <Button type="button" size="sm" className="mt-2" onClick={() => { onApply(s); setStatus("idle"); toast.success("Suggestion applied"); }}><Check /> Apply</Button>
            </div>
          ))}
          <Button type="button" size="sm" variant="ghost" onClick={() => setStatus("idle")}><X /> Dismiss</Button>
        </div>
      )}
    </div>
  );
}
